# Simple-Calculator-C-
Calculator Program is a very simple mini project in C++, built as a console application without using graphics features. It’s just a demonstration of the use of some built in functions and stream class in C++ language.
