# Snake-Game-2D-C-
The Simple Snake Game is a single-player game. Here, the player has to control the black rectangular-shaped box (termed as a snake) on a bordered plane.
