# Login-Form-In-CPP
A registration form can be defined as the collection of some fields that a user needs to fill in order to register to a particular organization, website, services, etc.
